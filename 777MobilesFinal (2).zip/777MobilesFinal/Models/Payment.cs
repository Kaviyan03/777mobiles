﻿namespace _777MobilesFinal.Models
{
    public class Payment
    {
    }
}

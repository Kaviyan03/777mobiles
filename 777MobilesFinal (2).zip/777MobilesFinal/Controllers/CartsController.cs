﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using _777MobilesFinal.Models;

namespace _777MobilesFinal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CartsController : ControllerBase
    {
        private readonly _777MobilesFinalContext _context;

        public CartsController(_777MobilesFinalContext context)
        {
            _context = context;
        }

        // GET: api/Carts
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Cart>>> GetAddToCart()
        {
            return await _context.AddToCart.ToListAsync();
        }

        // GET: api/Carts/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Cart>> GetCart(int id)
        {
            var cart = await _context.AddToCart.FindAsync(id);

            if (cart == null)
            {
                return NotFound();
            }

            return cart;
        }

        // PUT: api/Carts/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCart(int id, Cart cart)
        {
            if (id != cart.CId)
            {
                return BadRequest();
            }

            _context.Entry(cart).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CartExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Carts
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Cart>> PostCart(Cart cart)
        {
            _context.AddToCart.Add(cart);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCart", new { id = cart.CId }, cart);
        }

        // DELETE: api/Carts/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Cart>> DeleteCart(int id)
        {
            var cart = await _context.AddToCart.FindAsync(id);
            if (cart == null)
            {
                return NotFound();
            }

            _context.AddToCart.Remove(cart);
            await _context.SaveChangesAsync();

            return cart;
        }
        [HttpGet("user/{userid}")]
        public async Task<ActionResult<IEnumerable<Cart>>> GetBookingsByUserId(int userId)
        {
            // Retrieve and return booking history based on the userid
            var bookingHistory = await _context.AddToCart
                .Where(b => b.UserId == userId)
                .ToListAsync();


            if (bookingHistory.Count == 0)
            {
                return NotFound("No booking history found for the user.");
            }

            return Ok(bookingHistory);
        }


            private bool CartExists(int id)
        {
            return _context.AddToCart.Any(e => e.CId == id);
        }
    }
}
